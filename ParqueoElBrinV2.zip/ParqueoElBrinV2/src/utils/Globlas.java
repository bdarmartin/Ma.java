package utils;

/**
 * Class Globlas
 */
public class Globlas {
    public static SystemData cli1;
}
