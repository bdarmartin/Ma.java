package utils;

import modelo.Producto;

/**
 * Class ItemOrden
 */
public class ItemOrden {
    int noLinea;
    int cantidad;
    Producto producto;

    public ItemOrden(int noLinea, int cantidad, Producto producto) {
        this.noLinea = noLinea;
        this.cantidad = cantidad;
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "ItemOrden{" +
                "noLinea=" + noLinea +
                ", cantidad=" + cantidad +
                ", producto=" + producto +
                '}';
    }
}
