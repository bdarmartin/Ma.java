package utils;

import modelo.Orden;
import modelo.Cliente;
import modelo.Producto;

import java.util.ArrayList;

/**
 * Class SystemData
 */
public class SystemData {
    public static ArrayList<Cliente> clientes = new ArrayList<>();
    public static ArrayList<Producto> productos = new ArrayList<>();
    public static ArrayList<Orden> ordenes = new ArrayList<>();

    /**
     * @param c the client
     */
    public void addCliente(Cliente c) {
        clientes.add(c);
    }

    /**
     * @param p the product
     */
    public void addProducto(Producto p) {
        productos.add(p);
    }

    /**
     * @param o the order
     */
    public void addOrden(Orden o) {
        ordenes.add(o);
    }

    /**
     * @return clientes
     */
    public static ArrayList<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @return productos
     */
    public static ArrayList<Producto> getProductos() {
        return productos;
    }

    /**
     * @return ordenes
     */
    public static ArrayList<Orden> getOrdenes() {
        return ordenes;
    }
}
