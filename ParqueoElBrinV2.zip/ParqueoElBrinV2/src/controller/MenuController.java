package controller;

import utils.Globlas;
import modelo.Cliente;
import javafx.fxml.FXML;
import utils.SystemData;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.layout.Pane;
import javafx.scene.input.MouseEvent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

/**
 * Class MenuController
 */
public class MenuController {
    public TextField txtNombreCliente;
    public TextField txtApellido;
    public TextField txtCorreo;
    public TextField txtTelefono;
    public TextField txtTipoCliente;
    public TableColumn tfId;
    public TableColumn tfNombreCliente;
    public TableColumn tfApellido;
    public TableColumn tfCorreo;
    public TableColumn tfTelefono;
    public TableColumn tfTipoCliente;
    public TableView tblClientes;
    public Pane paneCliente;
    public MenuItem itemProductos;
    public ChoiceBox<String> chBoxTipoCliente;
    ObservableList list = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        tfId.setCellValueFactory(new PropertyValueFactory<Cliente, Integer>("id"));
        tfNombreCliente.setCellValueFactory(new PropertyValueFactory<Cliente, String>("nombre"));
        tfApellido.setCellValueFactory(new PropertyValueFactory<Cliente, String>("apellido"));
        tfCorreo.setCellValueFactory(new PropertyValueFactory<Cliente, String>("correoElectronico"));
        tfTelefono.setCellValueFactory(new PropertyValueFactory<Cliente, String>("telefono"));
        tfTipoCliente.setCellValueFactory(new PropertyValueFactory<Cliente, String>("tipoCliente"));
        loadData();
    }

    /**
     * @param actionEvent the action
     */
    public void loadClientsAction(ActionEvent actionEvent) {
        Cliente c2 = new Cliente("JUan", "Camaney", "jancama@gmail.com", "90897856", "individual");
        Globlas.cli1.addCliente(c2);
        Cliente c3 = new Cliente("Pedro", "Paredes", "pedropa@hotmail.com", "12456789", "individual");
        Globlas.cli1.addCliente(c3);
        Cliente c4 = new Cliente("Carlos", "Pistolas", "capalos@gmail.com", "7976545", "empresa");
        Globlas.cli1.addCliente(c4);
        ObservableList<Cliente> dat = FXCollections.observableArrayList(Globlas.cli1.getClientes());
        tblClientes.setItems(dat);
    }

    /**
     * @param actionEvent the action
     */
    public void addClientAction(ActionEvent actionEvent) {
        try {
            Cliente c1 = new Cliente(txtNombreCliente.getText(), txtApellido.getText(), txtCorreo.getText(), txtTelefono.getText(), txtTipoCliente.getText());
            Globlas.cli1.addCliente(c1);
            ObservableList<Cliente> data = FXCollections.observableArrayList(Globlas.cli1.getClientes());
            tblClientes.setItems(data);
            txtNombreCliente.setText("");
            txtApellido.setText("");
            txtCorreo.setText("");
            txtTelefono.setText("");
            txtTipoCliente.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param actionEvent the action
     */
    public void showClientAction(ActionEvent actionEvent) {
        paneCliente.setVisible(true);
    }

    private void loadData() {
        list.removeAll(list);
        String tipo1 = "individual";
        String tipo2 = "empresa";
        list.addAll(tipo1, tipo2);
        chBoxTipoCliente.getItems().addAll(list);
    }

    /**
     * @param mouseEvent the action
     */
    public void selectClientAction(MouseEvent mouseEvent) {
        Cliente c = (Cliente) this.tblClientes.getSelectionModel().getSelectedItem();
        if (c != null) {
            this.txtNombreCliente.setText(c.getNombre());
            this.txtApellido.setText(c.getApellido());
            this.txtCorreo.setText(c.getCorreoElectronico());
            this.txtTelefono.setText(c.getTelefono());
            this.txtTipoCliente.setText(c.getTipoCliente());
        }
    }

    /**
     * @param actionEvent the action
     */
    public void clear(ActionEvent actionEvent) {
        Cliente c = (Cliente) this.tblClientes.getSelectionModel().getSelectedItem();

        if (c == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Debe seleccionar un cliente. ");
            alert.showAndWait();
        } else {
            Globlas.cli1.getClientes().remove(c);
            this.tblClientes.refresh();
        }
    }

    /**
     * @param actionEvent the action
     */
    @FXML
    public void showProductsFormAction(ActionEvent actionEvent) {
        try {
            Globlas.cli1 = new SystemData();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ProductosManejo.fxml"));
            Parent root = loader.load();
            ProductsController products = loader.getController();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Productos");
            stage.setScene(scene);
            stage.show();
            Stage stageLogin = (Stage) txtNombreCliente.getScene().getWindow();
            stageLogin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param actionEvent the action
     */
    @FXML
    public void showOrderFormAction(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/OrdenesCompras.fxml"));
            Parent root = loader.load();
            OrdersController orComp = loader.getController();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Ordenes de Compra");
            stage.setScene(scene);
            stage.show();
            Stage stageLogin = (Stage) txtNombreCliente.getScene().getWindow();
            stageLogin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param actionEvent the action
     */
    public void exitAction(ActionEvent actionEvent) {
        System.exit(0);
    }
}
