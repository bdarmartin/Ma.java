package controller;

import utils.Globlas;
import utils.SystemData;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;

import javax.swing.*;
import java.io.IOException;

/**
 * Class AuthController
 */
public class AuthController {
    public PasswordField contrasena;
    public TextField usuario;
    private static final String title = "Parqueo el Brin";

    /**
     * @param actionEvent the actionEvent
     */
    public void authAction(ActionEvent actionEvent) {
        try {
            if (usuario.getText().equals("brin_admin") && contrasena.getText().equals("brin_admin_2021")) {
                this.showMenu(usuario);
            } else if (usuario.getText().equals("brin_admin_2") && contrasena.getText().equals("brin_admin_2_2021")) {
                this.showMenu(usuario);
            } else {
                JOptionPane.showMessageDialog(null, "Parece que los datos ingresados no son correctos!", title, JOptionPane.ERROR_MESSAGE);
                usuario.setText("");
                contrasena.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param usuario the user
     * @throws IOException
     */
    private void showMenu(TextField usuario) throws IOException {
        JOptionPane.showMessageDialog(null, "Bienvenido " + usuario.getText(), title, JOptionPane.INFORMATION_MESSAGE);
        Globlas.cli1 = new SystemData();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
        Pane raiz = (Pane) fxmlLoader.load();
        Scene scene = new Scene(raiz, 750, 650);
        Stage stage = new Stage();
        stage.setTitle("Menu Principal");
        stage.setScene(scene);
        stage.show();
        Stage stageLogin = (Stage) usuario.getScene().getWindow();
        stageLogin.close();
    }
}
