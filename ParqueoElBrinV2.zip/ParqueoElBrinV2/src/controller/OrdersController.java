package controller;

import modelo.Orden;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.Date;
import java.io.IOException;

/**
 * Class OrdersController
 */
public class OrdersController {
    public TableView tblOrden;
    public TextField txtId;
    public TableColumn tcNo;
    public TableColumn tcProveedor;
    public TableColumn tcFecha;
    public TableColumn tcProducto;
    public TableColumn tcCantidad;
    public TableColumn tcPrecio;
    public TableColumn tcSubtotal;
    public TableColumn tcTotal;
    public TextField txtNo;
    public TextField txtProveedor;
    public TextField txtFecha;
    public TextField txtNombreProducto;
    public TextField txtCantidad;
    public TextField txtPrecioUnitario;
    public TableColumn tcDiasEnvio;
    public TableColumn tcTipoEnvio;
    public TableColumn tcEstado;
    public ChoiceBox<String> chBoxDiasEnvio;
    public ChoiceBox<String> chBoxTipoEnvio;
    public ChoiceBox<String> chBoxEstado;
    ObservableList list = FXCollections.observableArrayList();
    ObservableList list2 = FXCollections.observableArrayList();
    ObservableList list3 = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        tcNo.setCellFactory(new PropertyValueFactory<Orden, Integer>("id"));
        tcProveedor.setCellFactory(new PropertyValueFactory<Orden, String>("nombreProducto"));
        tcFecha.setCellFactory(new PropertyValueFactory<Orden, Date>("precioUnitario"));
        tcProducto.setCellFactory(new PropertyValueFactory<Orden, String>("id"));
        tcCantidad.setCellFactory(new PropertyValueFactory<Orden, Integer>("nombreProducto"));
        tcPrecio.setCellFactory(new PropertyValueFactory<Orden, Double>("id"));
        tcProveedor.setCellFactory(new PropertyValueFactory<Orden, String>("nombreProducto"));
        tcDiasEnvio.setCellFactory(new PropertyValueFactory<Orden, Integer>("nombreProducto"));
        tcTipoEnvio.setCellFactory(new PropertyValueFactory<Orden, String>("id"));
        tcEstado.setCellFactory(new PropertyValueFactory<Orden, String>("nombreProducto"));
        loadDataAction();
    }

    private void loadDataAction() {
        list.removeAll(list);
        String dia5 = "5";
        String dia10 = "10";
        String dia15 = "15";
        String dia30 = "30";
        list.addAll(dia5, dia10, dia15, dia30);
        chBoxDiasEnvio.getItems().addAll(list);
    }

    public void exitAction(ActionEvent actionEvent) {
        System.exit(0);
    }

    /**
     * @param actionEvent the action
     */
    public void showMenuAction(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
            Stage stageLogin = (Stage) txtNombreProducto.getScene().getWindow();
            stageLogin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
