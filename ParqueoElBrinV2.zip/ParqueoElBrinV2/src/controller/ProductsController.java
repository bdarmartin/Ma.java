package controller;

import utils.Globlas;
import modelo.Producto;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

/**
 * Class ProductsController
 */
public class ProductsController {
    public TextField txtNombreProducto;
    public TextField txtPrecioUnitario;
    public TableView tblProductos;
    public TableColumn tfId;
    public TableColumn tfProducto;
    public TableColumn tfPrecio;

    @FXML
    public void initialize() {
        tfId.setCellFactory(new PropertyValueFactory<Producto, Integer>("id"));
        tfProducto.setCellFactory(new PropertyValueFactory<Producto, String>("nombreProducto"));
        tfPrecio.setCellFactory(new PropertyValueFactory<Producto, Double>("precioUnitario"));
    }

    /**
     * @param actionEvent the action
     */
    public void addProducAction(ActionEvent actionEvent) {
        try {
            Producto p1 = new Producto(txtNombreProducto.getText(), Double.parseDouble(this.txtPrecioUnitario.getText()));
            Globlas.cli1.addProducto(p1);
            ObservableList<Producto> data = FXCollections.observableArrayList(Globlas.cli1.getProductos());
            tblProductos.setItems(data);
            txtNombreProducto.setText("");
            txtPrecioUnitario.setText("");

        } catch (NumberFormatException n) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error al crear producto");
            alert.setContentText("Existe uno o varios errores en el formulario");
            alert.showAndWait();
        }
    }

    /**
     * @param actionEvent the action
     */
    public void exitAction(ActionEvent actionEvent) {
        System.exit(0);
    }

    /**
     * @param actionEvent the action
     */
    public void showMenuAction(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
            Stage stageLogin = (Stage) txtNombreProducto.getScene().getWindow();
            stageLogin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
