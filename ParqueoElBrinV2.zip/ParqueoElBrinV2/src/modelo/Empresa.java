package modelo;

public class Empresa extends Cliente {
    private String contacto;
    private int descuento;

    public Empresa(String nombre, String apellido, String correoElectronico, String telefono, String tipoCliente, String contacto, int descuesto) {
        super(nombre, apellido, correoElectronico, telefono, tipoCliente);
        this.contacto = contacto;
        this.descuento = descuesto;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public int getDescuento() {
        return descuento;
    }

    public void setDescuento(int descuento) {
        this.descuento = descuento;
    }

    @Override
    public String toString() {
        return "Empresa{" +
                "contacto='" + contacto + '\'' +
                ", descuento=" + descuento +
                '}';
    }
}
