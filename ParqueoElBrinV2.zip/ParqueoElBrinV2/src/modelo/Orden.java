package modelo;

import utils.ItemOrden;

import java.util.Date;

public class Orden {
    int id;
    public Cliente cliente;
    public ItemOrden item1;
    public ItemOrden item2;
    public Date fechaOrden;
    public double precioEnvio;
    public double total;
    public String tipoEnvio;
    public String estado;
    public static int sigIdOrden;
    public int diasEnvio;

    public Orden() {
        this.id = sigIdOrden++;
        this.fechaOrden = new Date();
        this.total = 0.0;
    }

    public Orden(Date fechaOrden) {
        this.fechaOrden = fechaOrden;
    }

    public Orden(Cliente cliente, Date fechaOrden) {
        this.cliente = cliente;
        this.fechaOrden = fechaOrden;
    }
}
