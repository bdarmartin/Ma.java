package modelo;

public class Individual extends Cliente {
    private String dpi;

    public Individual(String dpi, String nombre, String apellido, String correoElectronico, String telefono, String tipoCliente) {
        super(nombre, apellido, correoElectronico, telefono, tipoCliente);
        this.dpi = dpi;
    }

    public String getDpi() {
        return dpi;
    }

    public void setDpi(String dpi) {
        this.dpi = dpi;
    }

    @Override
    public String toString() {
        return "Individual{" +
                "dpi='" + dpi + '\'' +
                '}';
    }
}
