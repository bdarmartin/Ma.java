import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.application.Application;

/**
 * @author elBri
 */
public class Main extends Application {
    /**
     * @param stage the stage
     */
    @Override
    public void start(Stage stage) throws Exception {
        Pane layout = (Pane) FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
        Scene scene = new Scene(layout, 300, 150);
        stage.setTitle("Parqueo el Brin");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the args
     */
    public static void main(String[] args) {
        launch(args);
    }
}
